# BoxDetect > 2024-01-11 9:26pm
https://universe.roboflow.com/jinpaoobox/boxdetect-i5ho6

Provided by a Roboflow user
License: CC BY 4.0

